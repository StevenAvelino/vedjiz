import { Supplier } from './Supplier'

export class Product {
  private _id: number
  private _productName: string
  private _price: number
  private _unitName: string
  private _suppliers: Array<Supplier>
  private _picture: string
  private _stock: number
  private _updated: boolean

  constructor(id:number, name:string, price:number, unit:string, suppliers:Array<Supplier>, path: string, stock: number) {
    this.id = id
    this.productName = name
    this.price = price
    this.unitName = unit
    this.suppliers = suppliers
    this.picture = path
    this.stock = stock
    this.updated = false
  }

  update(name, price, unit, stock, path) {
    this.productName = name
    this.price = price
    this.unitName = unit
    this.stock = stock
    this.picture = path
  }

  set productName(name:string) {
    this._productName = name
  }

  get productName(): string {
    return this._productName
  }

  set price(price:number) {
    this._price = price
  }

  get price(): number {
    return this._price
  }

  set unitName(unit:string) {
    this._unitName = unit
  }

  get unitName(): string {
    return this._unitName
  }

  set suppliers(suppliers:Array<Supplier>) {
    this._suppliers = suppliers
  }

  get suppliers(): Array<Supplier> {
    return this._suppliers
  }

  set picture(path:string) {
    this._picture = path
  }

  get picture(): string {
    return this._picture
  }

  set stock(stock:number) {
    this._stock = stock
  }

  get stock(): number {
    return this._stock
  }

  set id(id) {
    this._id = id
  }

  get id(): number {
    return this._id
  }

  set updated(updated) {
    this._updated = updated
  }

  get updated(): boolean {
    return this._updated
  }
}