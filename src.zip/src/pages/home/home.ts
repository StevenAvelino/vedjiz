import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NavController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

import { Product } from '../../models/Product';
import { ShowProductPage } from '../products/show/products';
import { CreateProductPage } from '../products/create/products';
import { Storage } from '@ionic/storage';
import { DataProvider } from '../../providers/data/data'

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  products: Product[]

  constructor(public navCtrl: NavController, private storage: Storage, public http: HttpClient, public dataProvider: DataProvider) {
    dataProvider.getProducts().then(res => {
      this.products = res
    })
    /*this.dataProvider.connectToDB().then(() => {
      this.dataProvider.getProducts().then(response => {
        this.products = response
      })
    }).catch(e => console.log(JSON.stringify(e)))*/
  }

  ionViewDidLoad() {
    
  }

  details(product) {
    this.navCtrl.push(ShowProductPage, {
      'product': product
    })
  }

  getProducts() {
    
  }

  createForm() {
    console.log(typeof(this.storage.get('products')))
    //console.log(this.dataProvider.updateProduct(this.products[0]))
    /*this.dataProvider.getProducts().then((products) => {
      console.log(products)
    })*/
    //this.navCtrl.push(CreateProductPage)
  }

  uploadData() {
    let updatedProducts = []
    for (let product of this.products) {
      if (product.updated) {
        updatedProducts.push(product)
      }
    }

    this.dataProvider.updateProducts(updatedProducts)
  }

}
