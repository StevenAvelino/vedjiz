import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from '../../models/Product'
import { Supplier } from '../../models/Supplier'
import { User } from '../../models/User'
import { Platform } from 'ionic-angular';
import 'rxjs/add/operator/map'
import { Storage } from '@ionic/storage';

@Injectable()
export class DataProvider {

  products: Array<Product> = []
  suppliers: Supplier[] = []
  users: User[] = []
  headers: HttpHeaders

  constructor(public http: HttpClient, public platform: Platform, public storage: Storage) {
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest'
    })
  }

  getProductsAPI() {
    return new Promise(resolve => {
      this.http.get('http://vedjserver.mycpnv.ch/api/v1/vegetables').subscribe(data => {
        resolve(data)
      }, err => {
        console.log(err)
      })
    })
  }

  getLastUpdate() {
    return new Promise(resolve => {
      this.http.get('http://vedjserver.mycpnv.ch/api/v1/lastupdate').subscribe(data => {
        resolve(data)
      }, err => {
        console.log(err)
      })
    })
  }

  updateProducts(changes) {
    this.http.patch('http://vedjserver.mycpnv.ch/api/v1/newstock', {changes: changes}, {headers: this.headers}).subscribe(res => {
      console.log(JSON.stringify(res))
    }, err => {
      console.log(JSON.stringify(err))
    })
  }

  getProducts() {
    return new Promise<Product[]>(resolve => {
      this.getLastUpdate().then(res => {
        this.storage.get('lastupdate').then(val => {
          if (val == null) {
            this.storage.set('lastupdate', res).then(() => {
              this.getProductsAPI().then(res => {
                this.storage.set('products', res).then(() => {
                  this.storage.get('products').then(val => {
                    this.products = val.map(p => {
                      return new Product(p.id, p.productName, p.price, p.unitName, [], p.picture, p.stock)
                    })
                    resolve(this.products)
                  }).catch(e => console.log(e))
                }).catch(e => console.log(e))
              })
            }).catch(e => console.log(e))
          } else {
            if (Date.parse(val.updated_at) >= Date.parse(JSON.parse(JSON.stringify(res)).updated_at)) {
              this.storage.get('products').then(val => {
                this.products = val.map(p => {
                  return new Product(p.id, p.productName, p.price, p.unitName, [], p.picture, p.stock)
                })
                resolve(this.products)
              }).catch(e => console.log(e) )
            } else {
              this.storage.set('lastupdate', res).then(() => {
                this.getProductsAPI().then(res => {
                  this.storage.set('products', res).then(() => {
                    this.storage.get('products').then(val => {
                      this.products = val.map(p => {
                        return new Product(p.id, p.productName, p.price, p.unitName, [], p.picture, p.stock)
                      })
                      resolve(this.products)
                    }).catch(e => console.log(e))
                  }).catch(e => console.log(e))
                }).catch(e => console.log(e))
              }).catch(e => console.log(e))
            }
          }
        }).catch(e => console.log(e))
      })
      
    })
  }


}